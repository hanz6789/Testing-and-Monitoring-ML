Example project for the course "Testing & Monitoring Machine Learning Model Deployments". For setup instructions, see the course lectures.
